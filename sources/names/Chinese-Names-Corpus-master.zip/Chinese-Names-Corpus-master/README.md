# 中文人名语料库（Chinese-Names-Corpus）

<strong>关于萌名（NameMoe）</strong>

萌名是一个基于大数据和自然语言处理技术的新取名产品。

通过分词工具对海量文本进行分词和词频统计。数据清洗后，得到千万级的人名词典。再对其进行性别、年龄、拼音、情感、人名指数等标记，最终形成5600万+的中文人名图谱。

本子项目可用于中文分词、人名识别等场景。

---

PS1：维护此项目，除个人兴趣外，主要是在此过程中，可通过任务驱动来不断学习和实践NLP、KG以及AI等相关前沿技术。

PS2：正在找工作，求内部推荐～ 移动医疗/SaaS后台/人工智能方向的 高级产品经理一枚。

PS3：请勿提交涉政issue，谢谢。

PS4：如将本项目转存到国内的某平台，请设置成0积分下载，并保留GitHub链接。

---

<strong>中文常见人名（Chinese_Names_Corpus）</strong>

数据大小：120万。

语料来源：从亿级人名语料中提取。

数据清洗：已清洗，但仍存有少量badcase。

<strong>新增人名生成器。</strong>

---

<strong>中文古代人名（Ancient_Names_Corpus）</strong>

数据大小：25万。

语料来源：多个人名词典汇总。

数据清洗：已清洗。

---

<strong>中文姓氏（Chinese_Family_Name）</strong>

数据大小：1千。

语料来源：从亿级人名语料中提取。

数据清洗：已清洗。

---

<strong>中文称呼（Chinese_Relationship）</strong>

数据大小：5千，称呼词根；18万，中文称呼。

语料来源：多个人名词典汇总。

数据清洗：已清洗，但仍存有大量badcase。

---

# 英文人名语料库（English-Names-Corpus）
<strong>翻译人名（English_Cn_Name_Corpus）</strong>

数据大小：48万。

语料来源：多个人名词典汇总。

数据清洗：已清洗，但仍存有少量badcase，以地名居多。

本语料的人名识别由网友 “[ltccss](https://github.com/ltccss)” 友情提供。

---

# 日文人名语料库（Japanese_Names_Corpus）
<strong>日文人名（Japanese_Names_Corpus）</strong>

数据大小：18万。

数据来源：从维基百科中提取。

数据清洗：已清洗，但仍存有少量badcase。

数据清洗过程详见：“[日本人名数据清洗分享](https://github.com/wainshine/Chinese-Names-Corpus/issues/4)”。

---

# 中文词典语料库（Chinese_Dict_Corpus）
<strong>成语词典（ChengYu_Corpus）</strong>

数据大小：5万。

语料来源：多个成语词典汇总。

数据清洗：已清洗。

---

## Stargazers over time

[![Stargazers over time](https://starchart.cc/wainshine/Chinese-Names-Corpus.svg)](https://starchart.cc/wainshine/Chinese-Names-Corpus)

---

<strong>更新时间：</strong>

更早的提交，不记得时间了。

删除了1000余非人名。 -2017.08.08

删除了5000余非人名。 -2017.11.25

新增了18万日文人名。 -2017.12.17

删除了1500余非人名（主要是日文地名）。 -2017.12.30

删除了约3万余非人名、或低频人名。 -2018.11.04

删除了2600余非人名、或低频人名。 -2019.04.15

删除了约1万余非人名、或低频人名。 -2019.07.27

将文件移动到文件夹。 -2019.10.21

新增人名生成器。 -2020.01.29

删除了约6万余非人名、或低频人名。 -2020.12.13

更新人名生成器。 -2021.11.22

删除了约700余非人名、或低频人名。 -2022.11.30

---

@萌名NameMoe 整理

2024.03.27
